public class Main {
    public static void main(String[]args) {
        BmiService service = new BmiService();
        double weight = 93.1;
        float height = 187;
        double bmi = service.calculate(weight, height);

        System.out.println(bmi);
    }
}
